export const environment = {
    production:false,
    apiUrl:"https://192.168.1.24"
};
