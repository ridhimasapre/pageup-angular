import { Token } from "@angular/compiler";

export const environment = {
    production:false,
    apiUrl:"https://192.168.1.46",
    token:"eyJhbGciOiJodHRwOi8vd3d3LnczLm9yZy8yMDAxLzA0L3htbGRzaWctbW9yZSNobWFjLXNoYTI1NiIsInR5cCI6IkpXVCJ9.eyJodHRwOi8vc2NoZW1hcy5taWNyb3NvZnQuY29tL3dzLzIwMDgvMDYvaWRlbnRpdHkvY2xhaW1zL3JvbGUiOiJTdXBlckFkbWluIiwiTmFtZSI6IlJpZGhpbWEgU2FwcmUiLCJJZCI6IjMiLCJSb2xlIjoiU3VwZXJBZG1pbiIsIkd1aWQiOiI4OTc4YjI2OS1iYTNiLTQyMDktOWYyNi0wZjU0NjEyMzlkN2IiLCJleHAiOjE3MjYwNDgwMTQsImlzcyI6Ikp3dElzc3VlciIsImF1ZCI6Ikp3dEF1ZGllbmNlIn0.XUZKMb8hdweOjqhcENVuALMlwDtdewTqKyYlvDXebks"
};
