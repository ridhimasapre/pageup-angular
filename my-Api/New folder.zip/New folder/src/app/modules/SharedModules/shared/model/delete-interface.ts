export interface DialogData{
    message: string;
}